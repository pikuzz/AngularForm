// tslint:disable-next-line:class-name
export class login {
    // tslint:disable-next-line:no-trailing-whitespace
    
       // tslint:disable-next-line:one-line
       constructor(public username: string, public password: any){}
    }
 