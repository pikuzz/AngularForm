export class User {  

    constructor(public username:string,public password:any,public email:any){}
 }